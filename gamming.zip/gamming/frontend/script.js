console.log("JavaScript loaded");

document.getElementById("loginForm")?.addEventListener("submit", function(e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  alert("Logging in as " + username);
});
document.getElementById("loginForm")?.addEventListener("submit", function(e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  localStorage.setItem("username", username);

  fetch("http://localhost:3000/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username })
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    window.location.href = "subjects.html";
  });
});
document.getElementById("loginForm")?.addEventListener("submit", function(e) {
    e.preventDefault();
    const username = document.getElementById("username").value;
    localStorage.setItem("username", username);
    window.location.href = "subjects.html";
  });
  
  // SUBJECT SELECTION
  function selectSubject(subject) {
    localStorage.setItem("subject", subject);
    window.location.href = "experiments.html";
  }
  
  // EXPERIMENT SELECTION
  document.addEventListener("DOMContentLoaded", () => {
    const subject = localStorage.getItem("subject");
    const experiments = {
      Physics: ["Refraction", "Motion"],
      Chemistry: ["Acid-Base", "Electrolysis"]
    };
  
    const container = document.getElementById("experimentList");
    if (container && experiments[subject]) {
      experiments[subject].forEach(exp => {
        const btn = document.createElement("button");
        btn.innerText = exp;
        btn.onclick = () => {
          localStorage.setItem("experiment", exp);
          window.location.href = "game.html";
        };
        container.appendChild(btn);
      });
    }
  
    const expTitle = localStorage.getItem("experiment");
    if (document.getElementById("experimentTitle")) {
      document.getElementById("experimentTitle").innerText = expTitle;
      document.getElementById("experimentInfo").innerText =
        "This is an interactive simulation of " + expTitle;
    }
  });
  
  // GAME START
  function startGame() {
    alert("🎮 Game started! Complete your virtual experiment.");
  }
  