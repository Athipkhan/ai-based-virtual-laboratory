const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const fs = require("fs");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("../frontend")); // Serve your frontend

// Mock login route
app.post("/api/login", (req, res) => {
  const { username } = req.body;
  console.log(`User logged in: ${username}`);
  res.json({ success: true, message: `Welcome ${username}` });
});

// Save user progress
app.post("/api/progress", (req, res) => {
  const { username, subject, experiment } = req.body;
  const data = { username, subject, experiment };
  fs.writeFileSync("data.json", JSON.stringify(data, null, 2));
  res.json({ success: true, message: "Progress saved!" });
});

// Get progress
app.get("/api/progress", (req, res) => {
  if (fs.existsSync("data.json")) {
    const data = fs.readFileSync("data.json");
    res.json(JSON.parse(data));
  } else {
    res.json({});
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
